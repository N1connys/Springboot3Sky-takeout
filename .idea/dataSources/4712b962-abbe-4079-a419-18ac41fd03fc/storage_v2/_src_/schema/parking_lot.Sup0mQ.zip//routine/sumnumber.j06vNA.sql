create
    definer = root@localhost function sumnumber(x int) returns int deterministic
begin
    declare sum int;
    declare number int;
    set sum=0;
    set number=50;
    while x<=50 do
        set sum=sum+x;
          set   x=x+1;
        end while;
    return sum;
end;

