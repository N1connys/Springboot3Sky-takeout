create definer = root@localhost trigger course_detrigger
    after delete
    on students
    for each row
    set@per1='helloworld';

