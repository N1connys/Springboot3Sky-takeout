create
    definer = root@localhost function ethree(num int) returns int deterministic
begin
        declare sum2 int ;
        declare sn int ;
        set sum2=0;
        set sn=51;
        while sn<=num do
                set sum2=sum2+sn;
                set sn=sn+2;
            end while;
            return sum2;
    end;

