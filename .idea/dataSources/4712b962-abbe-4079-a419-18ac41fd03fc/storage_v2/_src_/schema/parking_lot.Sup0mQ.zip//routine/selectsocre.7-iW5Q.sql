create
    definer = root@localhost procedure selectsocre(IN stu_id int)
begin
    select * from students
        where student_id=stu_id;
end;

