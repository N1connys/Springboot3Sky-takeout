create
    definer = root@localhost function case2two(x int) returns int deterministic
begin
        case x
            when 7 then set x=1;
            when 14 then set x=2;
            else set x =-1;
            end case;
    return x;
        end;

