create
    definer = root@localhost procedure changeemail(IN name varchar(10), IN u_age int)
begin
        update students set age=u_age where student_name=name;
    end;

