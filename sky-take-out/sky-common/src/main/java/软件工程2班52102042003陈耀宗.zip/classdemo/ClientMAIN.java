package classdemo;

public class ClientMAIN {
    public static void main(String[] args) {
        ClientMethod.Start();
    }

}
